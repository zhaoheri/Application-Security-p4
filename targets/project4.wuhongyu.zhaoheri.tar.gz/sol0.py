s = "zhaoheri\0AA+"
print s